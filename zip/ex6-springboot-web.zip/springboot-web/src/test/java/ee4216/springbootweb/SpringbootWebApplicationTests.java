package ee4216.springbootweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
