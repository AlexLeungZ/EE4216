<html>
    <head>
        <title>HTML Injection Example</title>
    </head>
    <body>
		<h1>We got you ;p</h1>
		<br>
		
		<?= $_POST['username'] ?> / <?= $_POST['password'] ?>
				
		<p>We are glad to see your username and password. </p>	
	<body>
<html>

