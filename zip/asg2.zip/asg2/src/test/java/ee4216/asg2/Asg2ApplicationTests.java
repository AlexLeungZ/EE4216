package ee4216.asg2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Asg2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
