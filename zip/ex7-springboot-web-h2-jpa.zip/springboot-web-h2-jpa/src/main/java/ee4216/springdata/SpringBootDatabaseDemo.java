package ee4216.springdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDatabaseDemo {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootDatabaseDemo.class, args);
    }


}
