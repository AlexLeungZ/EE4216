package ee4216.springbootconsole;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootConsoleDemoTests {

	@Test
	void contextLoads() {
	}

}
