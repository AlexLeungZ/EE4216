
package ee4216.springbootdi.inside;

/**
 *
 * @author vanting
 */
public interface Animal {
    
    
}
